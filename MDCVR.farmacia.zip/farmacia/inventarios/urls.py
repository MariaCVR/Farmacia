from django.urls import path
from . import views

urlpatterns = [
    path("listar/", views.listar_productos, name="listar_productos"),
    path("crear/", views.crear_producto, name="crear_producto"),
    path("stock/", views.gestionar_stock, name="gestionar_stock"),
    path("eliminar/<int:pk>/", views.eliminar_producto, name="eliminar_producto"),
    path("gestionar_stock/", views.gestionar_stock, name="gestionar_stock"),
    path("sucursales/", views.listar_sucursales, name="listar_sucursales"),
    path("sucursales/crear/", views.crear_sucursal, name="crear_sucursal"),
    path(
        "sucursales/actualizar/<int:pk>/",
        views.actualizar_sucursal,
        name="actualizar_sucursal",
    ),
    path(
        "sucursales/eliminar/<int:pk>/",
        views.eliminar_sucursal,
        name="eliminar_sucursal",
    ),
]
