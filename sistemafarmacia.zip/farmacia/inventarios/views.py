from django.shortcuts import render, redirect
from .forms import ProductoForm, StockForm
from .models import Producto, Stock


def listar_productos(request):
    productos = Producto.objects.all()
    return render(
        request, "inventarios/listar_productos.html", {"productos": productos}
    )


def crear_producto(request):
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("listar_productos")
    else:
        form = ProductoForm()
    return render(request, "inventarios/crear_producto.html", {"form": form})


def gestionar_stock(request):
    if request.method == "POST":
        form = StockForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("gestionar_stock")
    else:
        form = StockForm()
    stock = Stock.objects.all()
    return render(
        request, "inventarios/gestionar_stock.html", {"form": form, "stock": stock}
    )
