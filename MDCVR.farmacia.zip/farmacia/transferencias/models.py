from django.db import models
from usuarios.models import Usuario
from inventarios.models import Producto, Sucursal


class Transferencia(models.Model):
    ESTADO_CHOICES = [
        ("pendiente", "Pendiente"),
        ("aceptada", "Aceptada"),
        ("finalizada", "Finalizada"),
    ]

    sucursal_origen = models.ForeignKey(
        Sucursal, on_delete=models.CASCADE, related_name="transferencias_enviadas"
    )
    sucursal_destino = models.ForeignKey(
        Sucursal, on_delete=models.CASCADE, related_name="transferencias_recibidas"
    )
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    estado = models.CharField(
        max_length=20, choices=ESTADO_CHOICES, default="pendiente"
    )
    fecha_solicitud = models.DateTimeField(auto_now_add=True)
    fecha_finalizacion = models.DateTimeField(null=True, blank=True)
    cliente = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        limit_choices_to={"rol": "cliente"},
    )

    def __str__(self):
        return f"Transferencia {self.id} - {self.producto.nombre} ({self.estado})"
