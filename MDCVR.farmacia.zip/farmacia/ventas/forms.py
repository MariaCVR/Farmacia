from django import forms
from .models import Venta
from usuarios.models import Roles


class VentaForm(forms.ModelForm):
    class Meta:
        model = Venta
        fields = [
            "cliente",
            "producto",
            "cantidad",
        ]

    def __init__(self, *args, **kwargs):
        usuario = kwargs.pop("usuario", None)
        super().__init__(*args, **kwargs)

        # 🔹 Eliminar la selección de sucursal, porque se asigna automáticamente
        if "sucursal_retiro" in self.fields:
            del self.fields["sucursal_retiro"]

        # 🔹 Filtrar productos según la sucursal del empleado
        if usuario and usuario.rol == Roles.EMPLEADO and usuario.sucursal_asignada:
            from inventarios.models import Stock

            productos_en_sucursal = Stock.objects.filter(
                sucursal=usuario.sucursal_asignada
            ).values_list("producto", flat=True)

            self.fields["producto"].queryset = self.fields["producto"].queryset.filter(
                id__in=productos_en_sucursal
            )

        # 🔹 Aplicar estilos Bootstrap
        for field in self.fields.values():
            field.widget.attrs.update({"class": "form-control"})
