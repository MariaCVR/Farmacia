from django.contrib import admin
from .models import Producto, Stock, Sucursal


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    def changelist_view(self, request, extra_context=None):

        return redirect("listar_productos")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_producto")


@admin.register(Sucursal)
class SucursalAdmin(admin.ModelAdmin):
    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_sucursal")


@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ("sucursal", "producto", "cantidad")
    list_filter = ("sucursal", "producto")


from django.contrib import admin
from django.shortcuts import redirect
from .models import Producto, Sucursal
