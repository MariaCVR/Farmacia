from django.shortcuts import render, redirect, get_object_or_404
from .forms import PedidoForm
from .models import Pedido


def listar_pedidos(request):
    pedidos = Pedido.objects.all()
    return render(request, "pedidos/listar_pedidos.html", {"pedidos": pedidos})


def crear_pedido(request):
    if request.method == "POST":
        form = PedidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("listar_pedidos")
    else:
        form = PedidoForm()
    return render(request, "pedidos/crear_pedido.html", {"form": form})


def detalle_pedido(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    return render(request, "pedidos/detalle_pedido.html", {"pedido": pedido})


def eliminar_pedido(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    if request.method == "POST":
        pedido.delete()
        return redirect("listar_pedidos")
    return render(request, "pedidos/eliminar_pedido.html", {"pedido": pedido})


def listar_pedidos(request):
    pedidos = Pedido.objects.all()
    return render(request, "pedidos/listar_pedidos.html", {"pedidos": pedidos})


def crear_pedido(request):
    if request.method == "POST":
        form = PedidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("listar_pedidos")
    else:
        form = PedidoForm()
    return render(request, "pedidos/crear_pedido.html", {"form": form})
