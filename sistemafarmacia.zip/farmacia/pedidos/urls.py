from django.urls import path
from . import views

urlpatterns = [
    path("listar/", views.listar_pedidos, name="listar_pedidos"),
    path("crear/", views.crear_pedido, name="crear_pedido"),
    path("detalle/<int:pk>/", views.detalle_pedido, name="detalle_pedido"),
    path("eliminar/<int:pk>/", views.eliminar_pedido, name="eliminar_pedido"),
]
