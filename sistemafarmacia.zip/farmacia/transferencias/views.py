from django.shortcuts import render, redirect
from .forms import TransferenciaForm
from .models import Transferencia


def listar_transferencias(request):
    transferencias = Transferencia.objects.all()
    return render(
        request,
        "transferencias/listar_transferencias.html",
        {"transferencias": transferencias},
    )


def crear_transferencia(request):
    if request.method == "POST":
        form = TransferenciaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("listar_transferencias")
    else:
        form = TransferenciaForm()
    return render(request, "transferencias/crear_transferencia.html", {"form": form})
