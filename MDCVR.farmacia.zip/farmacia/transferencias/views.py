from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import TransferenciaForm
from .models import Transferencia
from inventarios.models import Stock, Producto, Sucursal
from usuarios.models import Roles
from django.utils import timezone
from ventas.models import Venta


@login_required
def listar_transferencias(request):
    usuario = request.user
    if usuario.is_superuser:
        transferencias = Transferencia.objects.all()
    else:
        transferencias = Transferencia.objects.filter(
            sucursal_origen=usuario.sucursal_asignada
        ) | Transferencia.objects.filter(sucursal_destino=usuario.sucursal_asignada)
    contexto = {
        "transferencias": transferencias,
        "sucursal_id": (
            transferencias.first().sucursal_origen.id if transferencias.exists() else 1
        ),
        "producto_id": (
            transferencias.first().producto.id if transferencias.exists() else 1
        ),
    }
    return render(request, "transferencias/listar_transferencias.html", contexto)


@login_required
def crear_transferencia(request, sucursal_id=None, producto_id=None):
    """Permite registrar una transferencia desde otra sucursal a la actual"""

    if request.user.rol != "empleado":
        messages.error(request, "Solo los empleados pueden solicitar transferencias.")
        return redirect("listar_transferencias")

    sucursal_origen = get_object_or_404(Sucursal, id=sucursal_id)
    producto = get_object_or_404(Producto, id=producto_id)
    sucursal_destino = request.user.sucursal_asignada

    if request.method == "POST":
        form = TransferenciaForm(request.POST)
        if form.is_valid():
            transferencia = form.save(commit=False)
            transferencia.sucursal_origen = sucursal_origen
            transferencia.sucursal_destino = sucursal_destino
            transferencia.producto = producto
            transferencia.estado = "Pendiente"
            transferencia.save()
            messages.success(request, "Transferencia solicitada con éxito.")
            return redirect("listar_transferencias")
    else:
        form = TransferenciaForm(
            initial={"producto": producto, "sucursal_destino": sucursal_destino}
        )

    return render(request, "transferencias/crear_transferencia.html", {"form": form})


@login_required
def solicitar_transferencia(request, sucursal_id, producto_id, cantidad):
    usuario = request.user

    if usuario.rol != Roles.EMPLEADO:
        messages.error(request, "No tienes permisos para solicitar transferencias.")
        return redirect("listar_ventas")

    producto = get_object_or_404(Producto, id=producto_id)
    sucursal_destino = get_object_or_404(Sucursal, id=sucursal_id)
    sucursal_origen = usuario.sucursal_asignada

    stock_origen = Stock.objects.filter(
        sucursal=sucursal_destino, producto=producto
    ).first()

    print("stock_origen", stock_origen)

    if not stock_origen or stock_origen.cantidad <= 0:
        messages.error(
            request, "No hay stock suficiente para solicitar una transferencia."
        )
        return redirect(
            "buscar_sucursal_producto", producto_id=producto.id, cantidad=cantidad
        )

    Transferencia.objects.create(
        sucursal_origen=sucursal_origen,
        sucursal_destino=sucursal_destino,
        producto=producto,
        cantidad=cantidad,
        estado="pendiente",
    )

    messages.success(
        request,
        f"Se ha solicitado la transferencia de {cantidad} unidades desde {sucursal_origen.nombre}.",
    )
    return redirect("listar_transferencias")


@login_required
def aceptar_transferencia(request, transferencia_id):
    transferencia = get_object_or_404(Transferencia, id=transferencia_id)

    # 🔹 Verificar que la sucursal destino es la del usuario
    if request.user.sucursal_asignada != transferencia.sucursal_destino:
        messages.error(request, "No tienes permiso para aceptar esta transferencia.")
        return redirect("listar_transferencias")

    if transferencia.estado != "pendiente":
        messages.error(request, "Esta transferencia ya fue procesada.")
        return redirect("listar_transferencias")

    if request.method == "POST":
        # 🔹 Aceptar la transferencia
        transferencia.estado = "aceptada"
        transferencia.save()

        messages.success(
            request, "Transferencia aceptada. Ahora puedes despacharla al cliente."
        )
        return redirect("listar_transferencias")

    return render(
        request,
        "transferencias/aceptar_transferencia.html",
        {"transferencia": transferencia},
    )


@login_required
def finalizar_transferencia(request, transferencia_id):
    transferencia = get_object_or_404(Transferencia, id=transferencia_id)

    # 🔹 Verificamos que el usuario pertenece a la sucursal destino
    if request.user.sucursal_asignada != transferencia.sucursal_destino:
        messages.error(request, "No puedes finalizar esta transferencia.")
        return redirect("listar_transferencias")

    # 🔹 Obtener el stock en la sucursal destino
    stock_destino = Stock.objects.filter(
        sucursal=transferencia.sucursal_destino, producto=transferencia.producto
    ).first()

    if not stock_destino or stock_destino.cantidad < transferencia.cantidad:
        messages.error(request, "No hay suficiente stock en la sucursal destino.")
        return redirect("listar_transferencias")

    # ✅ Reducir el stock en la sucursal destino
    stock_destino.cantidad -= transferencia.cantidad
    stock_destino.save()

    # 🔹 Marcar la transferencia como finalizada
    transferencia.estado = "Finalizada"
    transferencia.fecha_entrega = timezone.now()
    transferencia.save()

    messages.success(request, "Transferencia finalizada y stock actualizado.")
    return redirect("listar_transferencias")
