from django.urls import path
from . import views

urlpatterns = [
    path("listar/", views.listar_transferencias, name="listar_transferencias"),
    path("crear/", views.crear_transferencia, name="crear_transferencia"),
]
