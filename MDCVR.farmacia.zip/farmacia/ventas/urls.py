from django.urls import path
from . import views

urlpatterns = [
    path("listar/", views.listar_ventas, name="listar_ventas"),
    path("crear/", views.crear_venta, name="crear_venta"),
    path("detalle/<int:pk>/", views.detalle_venta, name="detalle_venta"),
    path("actualizar/<int:pk>/", views.actualizar_venta, name="actualizar_venta"),
    path("eliminar/<int:pk>/", views.eliminar_venta, name="eliminar_venta"),
    path(
        "buscar_sucursal/<int:producto_id>/<int:cantidad>/",
        views.buscar_sucursal_producto,
        name="buscar_sucursal_producto",
    ),
    path(
        "stock_disponible/<int:producto_id>/",
        views.obtener_stock_disponible,
        name="obtener_stock_disponible",
    ),
]
