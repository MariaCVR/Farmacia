from django.contrib import admin
from django.shortcuts import redirect
from .models import Usuario


@admin.register(Usuario)
class PedidoAdmin(admin.ModelAdmin):

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("registro")
