from django.db import models


class Transferencia(models.Model):
    sucursal_origen = models.ForeignKey(
        "inventarios.Sucursal",
        related_name="transferencias_salida",
        on_delete=models.CASCADE,
    )
    sucursal_destino = models.ForeignKey(
        "inventarios.Sucursal",
        related_name="transferencias_entrada",
        on_delete=models.CASCADE,
    )
    producto = models.ForeignKey("inventarios.Producto", on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    fecha = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.producto.nombre} ({self.cantidad}) - {self.sucursal_origen} -> {self.sucursal_destino}"
