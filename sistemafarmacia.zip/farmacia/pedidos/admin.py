from django.contrib import admin
from django.shortcuts import redirect
from django.urls import reverse
from .models import Pedido


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        return redirect("listar_pedidos")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_pedido")

    def response_change(self, request, obj):
        return redirect(reverse("actualizar_pedido", kwargs={"pk": obj.pk}))
