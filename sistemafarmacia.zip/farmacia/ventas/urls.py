from django.urls import path
from . import views

urlpatterns = [
    path("listar/", views.listar_ventas, name="listar_ventas"),
    path("crear/", views.crear_venta, name="crear_venta"),
]
