from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import ProductoForm, StockForm, SucursalForm
from .models import Producto, Stock, Sucursal


def listar_productos(request):
    productos = Producto.objects.all()
    return render(
        request, "inventarios/listar_productos.html", {"productos": productos}
    )


def crear_producto(request):
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("listar_productos")
    else:
        form = ProductoForm()
    return render(request, "inventarios/crear_producto.html", {"form": form})


def eliminar_producto(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    producto.delete()
    messages.success(
        request, f'El producto "{producto.nombre}" ha sido eliminado correctamente.'
    )
    return redirect("listar_productos")


def gestionar_stock(request):
    if request.method == "POST":
        form = StockForm(request.POST)
        if form.is_valid():
            sucursal = form.cleaned_data["sucursal"]
            producto = form.cleaned_data["producto"]
            cantidad = form.cleaned_data["cantidad"]

            stock_existente = Stock.objects.filter(
                sucursal=sucursal, producto=producto
            ).first()

            if stock_existente:
                stock_existente.cantidad += cantidad
                stock_existente.save()
                messages.success(
                    request,
                    f"Se han añadido {cantidad} unidades de {producto.nombre} en {sucursal.nombre}.",
                )
            else:
                form.save()
                messages.success(
                    request,
                    f"Se ha registrado {cantidad} unidades de {producto.nombre} en {sucursal.nombre}.",
                )

            return redirect("gestionar_stock")
    else:
        form = StockForm()

    stock = Stock.objects.all()
    return render(
        request, "inventarios/gestionar_stock.html", {"form": form, "stock": stock}
    )


def listar_sucursales(request):
    sucursales = Sucursal.objects.all()
    return render(
        request, "inventarios/listar_sucursales.html", {"sucursales": sucursales}
    )


def crear_sucursal(request):
    if request.method == "POST":
        form = SucursalForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Sucursal creada correctamente.")
            return redirect("listar_sucursales")
    else:
        form = SucursalForm()

    return render(request, "inventarios/crear_sucursal.html", {"form": form})


def actualizar_sucursal(request, pk):
    sucursal = get_object_or_404(Sucursal, pk=pk)

    if request.method == "POST":
        form = SucursalForm(request.POST, instance=sucursal)
        if form.is_valid():
            form.save()
            messages.success(request, "Sucursal actualizada correctamente.")
            return redirect("listar_sucursales")
    else:
        form = SucursalForm(instance=sucursal)

    return render(
        request,
        "inventarios/actualizar_sucursal.html",
        {"form": form, "sucursal": sucursal},
    )


def eliminar_sucursal(request, pk):
    sucursal = get_object_or_404(Sucursal, pk=pk)
    sucursal.delete()
    messages.success(request, "Sucursal eliminada correctamente.")
    return redirect("listar_sucursales")
