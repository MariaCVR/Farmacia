from django.contrib import admin
from django.contrib import messages
from django.shortcuts import redirect
from .models import Transferencia


@admin.register(Transferencia)
class TransferenciaAdmin(admin.ModelAdmin):
    list_display = (
        "sucursal_origen",
        "sucursal_destino",
        "producto",
        "cantidad",
        "estado",
    )

    def changelist_view(self, request, extra_context=None):
        return redirect("listar_transferencias")

    def add_view(self, request, form_url="", extra_context=None):
        # Evitar redirección errónea sin parámetros
        messages.error(
            request, "Las transferencias deben crearse desde la vista de ventas."
        )
        return redirect("listar_transferencias")
