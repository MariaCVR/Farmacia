from django.contrib import admin
from .models import Venta, DetalleVenta


@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ("id", "sucursal", "cliente", "fecha", "total")
    list_filter = ("sucursal", "fecha")
    search_fields = ("id", "cliente__username")


@admin.register(DetalleVenta)
class DetalleVentaAdmin(admin.ModelAdmin):
    list_display = ("venta", "producto", "cantidad", "precio")
    list_filter = ("producto",)
