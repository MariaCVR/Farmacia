from django.contrib import admin
from django.shortcuts import redirect
from .models import Transferencia


@admin.register(Transferencia)
class TransferenciaAdmin(admin.ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        return redirect("listar_transferencias")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_transferencia")
