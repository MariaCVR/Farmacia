from django import forms
from .models import Pedido


class PedidoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ["cliente", "producto", "sucursal_retiro", "estado"]
        widgets = {
            "cliente": forms.Select(attrs={"class": "form-control"}),
            "producto": forms.Select(attrs={"class": "form-control"}),
            "sucursal_retiro": forms.Select(attrs={"class": "form-control"}),
            "estado": forms.Select(attrs={"class": "form-control"}),
        }
