from django.urls import path
from . import views

urlpatterns = [
    path("listar/", views.listar_transferencias, name="listar_transferencias"),
    path(
        "crear/<int:sucursal_id>/<int:producto_id>/",
        views.crear_transferencia,
        name="crear_transferencia",
    ),
    path(
        "solicitar/<int:sucursal_id>/<int:producto_id>/<int:cantidad>/",
        views.solicitar_transferencia,
        name="solicitar_transferencia",
    ),
    path(
        "aceptar/<int:transferencia_id>/",
        views.aceptar_transferencia,
        name="aceptar_transferencia",
    ),
    path(
        "finalizar/<int:transferencia_id>/",
        views.finalizar_transferencia,
        name="finalizar_transferencia",
    ),
]
