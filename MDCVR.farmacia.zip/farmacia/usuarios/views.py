from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from .forms import RegistroUsuarioForm
from django.contrib.auth.forms import AuthenticationForm
from .models import Roles
from .models import Usuario


def registrar_usuario(request):
    if request.method == "POST":
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            usuario = form.save()
            messages.success(request, "Usuario registrado correctamente.")
            return redirect("listar_usuarios")
        else:
            messages.error(request, "Hubo un error al registrar el usuario.")
            print("Errores del formulario:", form.errors)
    else:
        form = RegistroUsuarioForm()

    return render(request, "usuarios/registrar_usuario.html", {"form": form})


def listar_usuarios(request):
    usuarios = Usuario.objects.all()
    return render(request, "usuarios/listar_usuarios.html", {"usuarios": usuarios})


def actualizar_usuario(request, pk):
    usuario = get_object_or_404(Usuario, pk=pk)

    if request.method == "POST":
        form = RegistroUsuarioForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            messages.success(request, "Usuario actualizado correctamente.")
            return redirect("listar_usuarios")
    else:
        form = RegistroUsuarioForm(instance=usuario)

    return render(
        request, "usuarios/actualizar_usuario.html", {"form": form, "usuario": usuario}
    )


def eliminar_usuario(request, pk):
    usuario = get_object_or_404(Usuario, pk=pk)

    if usuario.rol == Roles.ADMINISTRADOR:
        messages.error(request, "No puedes eliminar a un administrador.")
        return redirect("listar_usuarios")

    usuario.delete()
    messages.success(request, "Usuario eliminado correctamente.")
    return redirect("listar_usuarios")
