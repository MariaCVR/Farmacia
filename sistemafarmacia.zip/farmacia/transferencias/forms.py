from django import forms
from .models import Transferencia


class TransferenciaForm(forms.ModelForm):
    class Meta:
        model = Transferencia
        fields = ["sucursal_origen", "sucursal_destino", "producto", "cantidad"]
