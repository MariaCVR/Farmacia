from django.contrib import admin
from .models import Producto, Stock, Sucursal
from django.shortcuts import redirect


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        return redirect("listar_productos")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_producto")


@admin.register(Sucursal)
class SucursalAdmin(admin.ModelAdmin):
    list_display = ("nombre", "direccion")
    search_fields = ("nombre", "direccion")
    list_per_page = 10

    def changelist_view(self, request, extra_context=None):
        return redirect("listar_sucursales")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_sucursal")


@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    def add_view(self, request, form_url="", extra_context=None):
        return redirect("gestionar_stock")

    def changelist_view(self, request, extra_context=None):
        return redirect("gestionar_stock")
