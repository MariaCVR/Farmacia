from django.urls import path
from . import views

urlpatterns = [
    path("registrar/", views.registrar_usuario, name="registrar_usuario"),
    path("listar/", views.listar_usuarios, name="listar_usuarios"),
    path("actualizar/<int:pk>/", views.actualizar_usuario, name="actualizar_usuario"),
    path("eliminar/<int:pk>/", views.eliminar_usuario, name="eliminar_usuario"),
]
