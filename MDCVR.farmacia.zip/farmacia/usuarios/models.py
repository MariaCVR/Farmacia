from django.contrib.auth.models import AbstractUser
from django.db import models
from inventarios.models import Sucursal


class Roles(models.TextChoices):
    ADMINISTRADOR = "administrador", "Administrador"
    EMPLEADO = "empleado", "Empleado"
    CLIENTE = "cliente", "Cliente"


class Usuario(AbstractUser):
    rol = models.CharField(max_length=20, choices=Roles.choices, default=Roles.CLIENTE)
    sucursal_asignada = models.ForeignKey(
        Sucursal, on_delete=models.SET_NULL, null=True, blank=True
    )

    def save(self, *args, **kwargs):
        # Si el usuario es un empleado, debe tener una sucursal asignada obligatoriamente
        if self.rol == Roles.EMPLEADO and not self.sucursal_asignada:
            raise ValueError("Un empleado debe tener una sucursal asignada.")

        # Si el usuario es un cliente, no puede tener una sucursal
        if self.rol == Roles.CLIENTE:
            self.sucursal_asignada = None

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.username} ({self.rol})"
