from django import forms
from .models import Transferencia


class TransferenciaForm(forms.ModelForm):
    class Meta:
        model = Transferencia
        fields = ["producto", "sucursal_destino", "cantidad"]
        widgets = {
            "producto": forms.Select(attrs={"class": "form-control"}),
            "sucursal_destino": forms.Select(attrs={"class": "form-control"}),
            "cantidad": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
        }
