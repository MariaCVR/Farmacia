from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import VentaForm
from .models import Venta
from inventarios.models import Stock, Producto
from usuarios.models import Roles
from transferencias.models import Transferencia
from django.http import JsonResponse


@login_required
def listar_ventas(request):
    usuario = request.user

    if usuario.is_superuser:
        ventas = Venta.objects.all()
    else:
        ventas = Venta.objects.filter(sucursal_retiro=usuario.sucursal_asignada)

    return render(request, "ventas/listar_ventas.html", {"ventas": ventas})


@login_required
def crear_venta(request):
    usuario = request.user

    if usuario.rol != Roles.EMPLEADO:
        messages.error(request, "No tienes permisos para realizar ventas.")
        return redirect("listar_ventas")

    sucursal_actual = usuario.sucursal_asignada  # 🔹 Sucursal asignada al empleado

    if request.method == "POST":
        form = VentaForm(request.POST)
        if form.is_valid():
            venta = form.save(commit=False)
            venta.sucursal_retiro = (
                sucursal_actual  # 🔹 Se asigna la sucursal automáticamente
            )

            # 🔹 Verificar stock en la sucursal del empleado
            stock = Stock.objects.filter(
                sucursal=sucursal_actual, producto=venta.producto
            ).first()

            if stock and stock.cantidad >= venta.cantidad:
                # ✅ Hay stock suficiente, realizar la venta
                stock.cantidad -= venta.cantidad
                stock.save()
                venta.save()
                messages.success(request, "Venta realizada exitosamente.")
                return redirect("listar_ventas")
            else:
                return redirect(
                    "buscar_sucursal_producto",
                    producto_id=venta.producto.id,
                    cantidad=venta.cantidad,
                )

    else:
        form = VentaForm()

    return render(
        request, "ventas/crear_venta.html", {"form": form, "sucursal": sucursal_actual}
    )


@login_required
def buscar_sucursal_producto(request, producto_id, cantidad):
    usuario = request.user

    if usuario.rol != Roles.EMPLEADO:
        messages.error(request, "No tienes permisos para realizar esta acción.")
        return redirect("listar_ventas")

    producto = get_object_or_404(Producto, id=producto_id)

    sucursales_con_stock = Stock.objects.filter(
        producto=producto, cantidad__gt=0
    ).exclude(sucursal=usuario.sucursal_asignada)

    return render(
        request,
        "ventas/buscar_sucursal_producto.html",
        {
            "producto": producto,
            "sucursales_con_stock": sucursales_con_stock,
            "cantidad": cantidad,
        },
    )


@login_required
def procesar_transferencia(request, transferencia_id):
    transferencia = get_object_or_404(Transferencia, id=transferencia_id)

    if request.user.sucursal_asignada != transferencia.sucursal_destino:
        messages.error(request, "No puedes procesar esta transferencia.")
        return redirect("listar_transferencias")

    if request.method == "POST":
        stock_destino, created = Stock.objects.get_or_create(
            sucursal=transferencia.sucursal_destino,
            producto=transferencia.producto,
        )

        if stock_destino.cantidad < transferencia.cantidad:
            messages.error(
                request, "No hay suficiente stock para procesar la transferencia."
            )
            return redirect("listar_transferencias")

        stock_destino.cantidad -= transferencia.cantidad
        stock_destino.save()

        Venta.objects.create(
            cliente=None,  # En este caso, la transferencia no tiene un cliente asignado
            producto=transferencia.producto,
            cantidad=transferencia.cantidad,
            sucursal_retiro=transferencia.sucursal_destino,
            estado="pendiente",
        )

        transferencia.estado = "completada"
        transferencia.save()

        messages.success(request, "Transferencia procesada y venta registrada.")
        return redirect("listar_ventas")

    return render(
        request, "ventas/procesar_transferencia.html", {"transferencia": transferencia}
    )


def detalle_venta(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    return render(request, "ventas/detalle_venta.html", {"venta": venta})


def actualizar_venta(request, pk):
    venta = get_object_or_404(Venta, pk=pk)

    if request.method == "POST":
        form = VentaForm(request.POST, instance=venta)
        if form.is_valid():
            form.save()
            messages.success(request, "Venta actualizada correctamente.")
            return redirect("listar_ventas")
    else:
        form = VentaForm(instance=venta)

    return render(
        request, "ventas/actualizar_venta.html", {"form": form, "venta": venta}
    )


def eliminar_venta(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    venta.delete()
    messages.success(request, "Venta eliminada correctamente.")
    return redirect("listar_ventas")


@login_required
def obtener_stock_disponible(request, producto_id):
    usuario = request.user
    stock = Stock.objects.filter(
        sucursal=usuario.sucursal_asignada, producto_id=producto_id
    ).first()

    stock_disponible = stock.cantidad if stock else 0

    return JsonResponse({"stock": stock_disponible})
