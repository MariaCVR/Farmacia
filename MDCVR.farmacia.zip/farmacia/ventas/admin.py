from django.contrib import admin
from django.shortcuts import redirect
from django.urls import reverse
from .models import Venta


@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        return redirect("listar_ventas")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("crear_venta")

    def response_change(self, request, obj):
        return redirect(reverse("actualizar_venta", kwargs={"pk": obj.pk}))
