from django.contrib.auth.models import Permission
from django import forms
from .models import Usuario, Roles


class RegistroUsuarioForm(forms.ModelForm):
    password1 = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(attrs={"class": "form-control"}),
        required=False,
    )
    password2 = forms.CharField(
        label="Confirmar Contraseña",
        widget=forms.PasswordInput(attrs={"class": "form-control"}),
        required=False,
    )

    class Meta:
        model = Usuario
        fields = [
            "username",
            "email",
            "rol",
            "sucursal_asignada",
            "password1",
            "password2",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field in self.fields.values():
            field.widget.attrs.update({"class": "form-control"})

        if "data" in kwargs:
            rol = kwargs["data"].get("rol")
        else:
            rol = None

        if rol == Roles.CLIENTE:
            self.fields.pop("password1", None)
            self.fields.pop("password2", None)
            self.fields.pop("sucursal_asignada", None)
        elif rol == Roles.ADMINISTRADOR:
            self.fields.pop("sucursal_asignada", None)

    def clean(self):
        cleaned_data = super().clean()
        rol = cleaned_data.get("rol")

        if rol == Roles.CLIENTE:
            cleaned_data.pop("password1", None)
            cleaned_data.pop("password2", None)
            cleaned_data.pop("sucursal_asignada", None)
        elif rol in [Roles.EMPLEADO, Roles.ADMINISTRADOR]:
            password1 = cleaned_data.get("password1")
            password2 = cleaned_data.get("password2")

            if not password1:
                self.add_error("password1", "La contraseña es obligatoria.")
            if not password2:
                self.add_error("password2", "Confirma la contraseña.")
            if password1 and password2 and password1 != password2:
                self.add_error("password2", "Las contraseñas no coinciden.")

        if rol == Roles.EMPLEADO and not cleaned_data.get("sucursal_asignada"):
            self.add_error(
                "sucursal_asignada", "El empleado debe tener una sucursal asignada."
            )

        return cleaned_data

    def save(self, commit=True):
        usuario = super().save(commit=False)

        if usuario.rol == Roles.CLIENTE:
            usuario.set_unusable_password()
        else:
            usuario.is_staff = True
            password = self.cleaned_data.get("password1")
            if password:
                usuario.set_password(password)

        if commit:
            usuario.save()

            # ✅ Ahora que el usuario tiene ID, le asignamos los permisos
            if usuario.rol == Roles.EMPLEADO:
                permisos = Permission.objects.filter(
                    content_type__app_label__in=["ventas", "transferencias", "usuarios"]
                )
                usuario.user_permissions.set(permisos)

        return usuario
