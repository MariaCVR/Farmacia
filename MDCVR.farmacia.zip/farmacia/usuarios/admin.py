from django.contrib import admin
from django.urls import path
from django.shortcuts import redirect
from .models import Usuario
from .views import registrar_usuario  # Importamos la vista personalizada


class UsuarioAdmin(admin.ModelAdmin):
    list_display = ("username", "email", "rol", "sucursal_asignada")
    list_filter = ("rol", "sucursal_asignada")
    fields = ("username", "email", "rol", "sucursal_asignada")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if not request.user.is_superuser:
            return qs.filter(rol="empleado")  # Los empleados solo ven empleados
        return qs

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if not request.user.is_superuser:
            form.base_fields["rol"].disabled = True
        return form

    # ✅ Redirigir "Añadir Usuario" al formulario personalizado
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path("add/", self.admin_site.admin_view(self.registrar_usuario_redirect))
        ]
        return custom_urls + urls

    def registrar_usuario_redirect(self, request):
        return redirect("registrar_usuario")  # Redirige a la vista personalizada

    def changelist_view(self, request, extra_context=None):
        return redirect("listar_usuarios")

    def add_view(self, request, form_url="", extra_context=None):
        return redirect("registrar_usuario_redirect")


admin.site.register(Usuario, UsuarioAdmin)
