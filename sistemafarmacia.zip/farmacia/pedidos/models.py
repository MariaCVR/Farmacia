from django.db import models
from usuarios.models import Usuario
from inventarios.models import Producto, Sucursal


class Pedido(models.Model):
    ESTADO_CHOICES = [
        ("pendiente", "Pendiente"),
        ("completado", "Completado"),
        ("cancelado", "Cancelado"),
    ]

    cliente = models.ForeignKey(
        Usuario, on_delete=models.CASCADE, limit_choices_to={"rol": "cliente"}
    )
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    sucursal_retiro = models.ForeignKey(Sucursal, on_delete=models.CASCADE)
    fecha_pedido = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(
        max_length=20, choices=ESTADO_CHOICES, default="pendiente"
    )

    def __str__(self):
        return f"Pedido #{self.id} - {self.producto.nombre} - {self.estado}"
