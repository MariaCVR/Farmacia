from django.shortcuts import render, redirect
from .forms import VentaForm, DetalleVentaForm
from .models import Venta, DetalleVenta
from django.db import transaction


def listar_ventas(request):
    ventas = Venta.objects.all()
    return render(request, "ventas/listar_ventas.html", {"ventas": ventas})


def crear_venta(request):
    if request.method == "POST":
        venta_form = VentaForm(request.POST)
        detalle_form = DetalleVentaForm(request.POST)
        if venta_form.is_valid() and detalle_form.is_valid():
            with transaction.atomic():
                venta = venta_form.save()
                detalle = detalle_form.save(commit=False)
                detalle.venta = venta
                detalle.precio = detalle.producto.precio
                detalle.save()
                venta.total += detalle.precio * detalle.cantidad
                venta.save()
            return redirect("listar_ventas")
    else:
        venta_form = VentaForm()
        detalle_form = DetalleVentaForm()
    return render(
        request,
        "ventas/crear_venta.html",
        {"venta_form": venta_form, "detalle_form": detalle_form},
    )
